# ==============================================
# Lab Assignment 4 - String Manipulation (Q10–Q11)
# ==============================================

# Q10: Palindrome Rearrangement Checker
def palindrome_checker(s):
    # TODO:
    # - Return "Yes" if string can be rearranged into a palindrome
    # - Return "No" otherwise
    # - Return "input invalid" for empty or non-string
    pass
    a={}
    if type(s)!=str:return "input invalid"
    if not s:return "input invalid"
    for i in s:
        if i in a:
            del a[i]
        else:a[i]=1
    if len(s)%2 == len(a):
        return 'Yes'
    return 'No'
    

    


# Q11: String Rotation Validator
def rotation_checker(s1, s2):
    # TODO:
    # - Return True if s2 is a rotation of s1
    # - Return False otherwise
    # - Return "input invalid" if inputs are not strings or lengths differ
    pass
    if type(s1)!=str or type(s2)!=str:return "input invalid"
    if len(s1)!= len(s2):return "input invalid"
    s1l=list(s1)
    s2l=list(l2)
    n=len(s2l)
    if set(s1)!=set(s2):return False
    while 1:
        for i in n:
            if s2l(i-1) == s1l[0]:
                j=i
                for i1 in range(1,n):
                    if s2l(j) != s1l[i1]:break
                    j+=1
                return True
                    

        return False