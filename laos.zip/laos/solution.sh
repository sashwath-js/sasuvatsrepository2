#!/bin/bash

# ==============================================
# Lab Assignment 4 - Bash Section (Q1–Q6)
# ==============================================
# Instructions:
# - Fill in the code for each question in the TODO section.
# - DO NOT remove the "Qx:" markers (they are used for grading).
# - You may add helper commands, but outputs must match the expected format.
# ==============================================

# Q1
echo "Q1:"
# TODO: Extract unique words from essay.txt (case-insensitive), sort, and print in lowercase
# Your code here
cat essay.txt | tr 'A-Z' 'a-z' | tr -c 'a-z' '\n' | sort | uniq

echo ""


# Q2
echo "Q2:"
# TODO: Count regular files, directories, and symbolic links in current directory (non-recursive)
# Format:
# Files: X
# Directories: Y
# Symlinks: Z
# Your code here

echo "Files: $(ls -l | grep ^- | wc -l)"
echo "Directories: $(ls -l | grep ^d | wc -l)"
echo "Symlinks: $(ls -l | grep ^l | wc -l)"
echo ""


# Q3
echo "Q3:"
# TODO: Print top 5 largest files in 'bigfiles' directory (filename - size), sorted descending
# Format: filename - size
# Your code here
ls -lS bigfiles | grep ^- | head -5 | awk '{print $9 " - " $5}'

echo ""
#$9 and $5 reference columns in LS output which are file name and size

# Q4
echo "Q4:"
# TODO: Print essay.txt with line numbers (1-based, in format: "1: line content")
# Your code here
nl -w1 -s": " essay.txt

echo ""


# Q5
echo "Q5:"
# TODO: Print current user's info in format:
# User: <username>
# Home: <home_directory>
# Shell: <shell>
# Your code here
echo "User: $USER"
echo "Home: $HOME"
echo "Shell: $SHELL"

echo ""


# Q6
echo "Q6:"
# TODO: Find all files modified in last 24 hours in current directory (non-recursive)
# Your code here
find . -maxdepth 1 -type f -mtime -1
# using maxdepth instead of whole directory name